/***********************************************************************/
/*                                                                     */
/*  FILE        :stacksct.h                                            */
/*  DATE        :Tue, Oct 31, 2006                                     */
/*  DESCRIPTION :Setting of Stack area                                 */
/*  CPU TYPE    :                                                      */
/*                                                                     */
/*  NOTE:THIS IS A TYPICAL EXAMPLE.                                    */
/*                                                                     */
/***********************************************************************/
#pragma stacksize su=0x100
#pragma stacksize si=0x300
