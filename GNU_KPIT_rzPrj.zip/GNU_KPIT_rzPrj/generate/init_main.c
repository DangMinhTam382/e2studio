/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/
/*******************************************************************************
* System Name  : EC-1 Init program
* File Name    : init_main.c
* Version      : 0.1
* Device       : R9A06G0xx
* Abstract     : Main program for EC-1 Init program
* OS           : not use
* H/W Platform : none
* Description  : Initialize the peripheral settings of EC-1
* Limitation   : none
*******************************************************************************/
/*******************************************************************************
* History      : DD.MM.YYYY Version  Description
*              :                     First Release
*******************************************************************************/

/*******************************************************************************
Includes <System Includes> , "Project Includes"
*******************************************************************************/
#include "typedefine.h"
#include "iodefine.h"
#include "r_system.h"
#include "r_icu_init.h"
#include "r_mpc.h"
#include "r_port.h"
#include "r_ecm.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Imported global variables and functions (from other files)
*******************************************************************************/

/*******************************************************************************
Exported global variables and functions (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private variables and functions
*******************************************************************************/
int main(void);
void port_init(void);
void ecm_init(void);
void icu_init(void);
void soft_wait(void);

/*******************************************************************************
* Outline      : main processing
* Function Name: main
* Description  : Initialize the peripheral settings of EC-1.
* Arguments    : none
* Return Value : none
*******************************************************************************/
int main (void)
{
    /* Initialize the port function */
    port_init();
    
    /* Initialize the ECM function */
    ecm_init();
    
    /* Initialize the ICU settings */
    icu_init();    

    while (1)
    {
    
        soft_wait();  // Soft wait for blinking LED0
        
    }
   
}
/*******************************************************************************
 End of function main
*******************************************************************************/

/*******************************************************************************
* Function Name: port_init
* Description  : Initialize port setting as following.
* Arguments    : none
* Return Value : none
*******************************************************************************/
void port_init(void)
{

}

/*******************************************************************************
 End of function port_init
*******************************************************************************/

/*******************************************************************************
* Function Name: ecm_init
* Description  : Initialize ECM setting as following.                              
* Arguments    : none
* Return Value : none
*******************************************************************************/
void ecm_init(void)
{
    volatile uint8_t result;
    
    /* Initialize ECM function  */
    R_ECM_Init();
    
}

/*******************************************************************************
 End of function ecm_init
*******************************************************************************/

/*******************************************************************************
* Function Name: icu_init
* Description  : Initialize Interrupt Controller Unit setting.
* Arguments    : none
* Return Value : none
*******************************************************************************/
void icu_init(void)
{

    /* Enable IRQ interrupt (Clear CPSR.I bit to 0) */
    asm("cpsie i");   // Clear CPSR.I bit to 0 
    asm("isb");       // Ensuring Context-changing
    
}

/*******************************************************************************
 End of function icu_init
*******************************************************************************/

/*******************************************************************************
* Function Name: soft_wait
* Description  : soft wait function using NOP 
* Arguments    : none
* Return Value : none
*******************************************************************************/
void soft_wait(void)
{
    uint32_t loop;
    
    for (loop = 0; loop < 10000000 ; loop++ )  
    {
        asm("nop");  
    }
    
}

/*******************************************************************************
 End of function soft_wait
*******************************************************************************/

/* End of File */


