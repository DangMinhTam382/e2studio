/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/
/*******************************************************************************
* System Name  : EC-1 Init program
* File Name    : r_icu_init.h
* Version      : 0.1
* Device       : R9A06G0xx
* Abstract     : API for ICU init
* OS           : not use
* H/W Platform : none
* Description  : Initialize interrupt controller unit.
* Limitation   : none
*******************************************************************************/
/*******************************************************************************
* History      : DD.MM.YYYY Version  Description
*              :                     First Release
*******************************************************************************/

#ifndef _R_ICU_INIT_HEADER_
#define _R_ICU_INIT_HEADER_

/*******************************************************************************
Macro definitions
*******************************************************************************/

#define ICU_EXT_PIN_0  (0)
#define ICU_EXT_PIN_1  (1)
#define ICU_EXT_PIN_2  (2)
#define ICU_EXT_PIN_3  (3)
#define ICU_EXT_PIN_4  (4)
#define ICU_EXT_PIN_6  (6)
#define ICU_EXT_PIN_7  (7)
#define ICU_EXT_PIN_9  (9)
#define ICU_EXT_PIN_11 (11)
#define ICU_EXT_PIN_12 (12)
#define ICU_EXT_PIN_13 (13)
#define ICU_EXT_PIN_14 (14)

#define ICU_DETECT_LOW       (0x00)
#define ICU_DETECT_FALL      (0x04)
#define ICU_DETECT_RISE      (0x08)
#define ICU_DETECT_RISE_FALL (0x0C)

#define ICU_DNF_DIVISION_1  (0)
#define ICU_DNF_DIVISION_8  (1)
#define ICU_DNF_DIVISION_32 (2)
#define ICU_DNF_DIVISION_64 (3)
#define ICU_DNF_NO_USE      (4)

#define ICU_VEC_NUM_2   (2)
#define ICU_VEC_NUM_3   (3)
#define ICU_VEC_NUM_4   (4)
#define ICU_VEC_NUM_5   (5)
#define ICU_VEC_NUM_6   (6)
#define ICU_VEC_NUM_7   (7)
#define ICU_VEC_NUM_8   (8)
#define ICU_VEC_NUM_10  (10)
#define ICU_VEC_NUM_11  (11)
#define ICU_VEC_NUM_13  (13)
#define ICU_VEC_NUM_15  (15)
#define ICU_VEC_NUM_16  (16)
#define ICU_VEC_NUM_17  (17)
#define ICU_VEC_NUM_18  (18)
#define ICU_VEC_NUM_20  (20)
#define ICU_VEC_NUM_21  (21)
#define ICU_VEC_NUM_22  (22)
#define ICU_VEC_NUM_23  (23)
#define ICU_VEC_NUM_24  (24)
#define ICU_VEC_NUM_25  (25)
#define ICU_VEC_NUM_26  (26)
#define ICU_VEC_NUM_27  (27)
#define ICU_VEC_NUM_28  (28)
#define ICU_VEC_NUM_29  (29)
#define ICU_VEC_NUM_30  (30)
#define ICU_VEC_NUM_31  (31)
#define ICU_VEC_NUM_32  (32)
#define ICU_VEC_NUM_33  (33)
#define ICU_VEC_NUM_34  (34)
#define ICU_VEC_NUM_41  (41)
#define ICU_VEC_NUM_42  (42)
#define ICU_VEC_NUM_43  (43)
#define ICU_VEC_NUM_44  (44)
#define ICU_VEC_NUM_48  (48)
#define ICU_VEC_NUM_49  (49)
#define ICU_VEC_NUM_73  (73)
#define ICU_VEC_NUM_74  (74)
#define ICU_VEC_NUM_75  (75)
#define ICU_VEC_NUM_76  (76)
#define ICU_VEC_NUM_77  (77)
#define ICU_VEC_NUM_78  (78)
#define ICU_VEC_NUM_79  (79)
#define ICU_VEC_NUM_80  (80)
#define ICU_VEC_NUM_81  (81)
#define ICU_VEC_NUM_82  (82)
#define ICU_VEC_NUM_83  (83)
#define ICU_VEC_NUM_84  (84)
#define ICU_VEC_NUM_85  (85)
#define ICU_VEC_NUM_86  (86)
#define ICU_VEC_NUM_87  (87)
#define ICU_VEC_NUM_96  (96)
#define ICU_VEC_NUM_97  (97)
#define ICU_VEC_NUM_98  (98)
#define ICU_VEC_NUM_99  (99)
#define ICU_VEC_NUM_100 (100)
#define ICU_VEC_NUM_101 (101)
#define ICU_VEC_NUM_102 (102)
#define ICU_VEC_NUM_103 (103)
#define ICU_VEC_NUM_104 (104)
#define ICU_VEC_NUM_107 (107)
#define ICU_VEC_NUM_108 (108)
#define ICU_VEC_NUM_109 (109)
#define ICU_VEC_NUM_110 (110)
#define ICU_VEC_NUM_111 (111)
#define ICU_VEC_NUM_112 (112)
#define ICU_VEC_NUM_113 (113)
#define ICU_VEC_NUM_114 (114)
#define ICU_VEC_NUM_115 (115)
#define ICU_VEC_NUM_116 (116)
#define ICU_VEC_NUM_117 (117)
#define ICU_VEC_NUM_118 (118)
#define ICU_VEC_NUM_119 (119)
#define ICU_VEC_NUM_120 (120)
#define ICU_VEC_NUM_124 (124)
#define ICU_VEC_NUM_125 (125)
#define ICU_VEC_NUM_126 (126)
#define ICU_VEC_NUM_242 (242)
#define ICU_VEC_NUM_243 (243)
#define ICU_VEC_NUM_251 (251)
#define ICU_VEC_NUM_252 (252)
#define ICU_VEC_NUM_261 (261)
#define ICU_VEC_NUM_262 (262)
#define ICU_VEC_NUM_264 (264)
#define ICU_VEC_NUM_293 (293)
#define ICU_VEC_NUM_294 (294)
#define ICU_VEC_NUM_299 (299)
#define ICU_VEC_NUM_300 (300)

#define ICU_TYPE_LEVEL (0)
#define ICU_TYPE_EDGE  (1)

#define ICU_PRIORITY_0  (0)
#define ICU_PRIORITY_1  (1)
#define ICU_PRIORITY_2  (2)
#define ICU_PRIORITY_3  (3)
#define ICU_PRIORITY_4  (4)
#define ICU_PRIORITY_5  (5)
#define ICU_PRIORITY_6  (6)
#define ICU_PRIORITY_7  (7)
#define ICU_PRIORITY_8  (8)
#define ICU_PRIORITY_9  (9)
#define ICU_PRIORITY_10 (10)
#define ICU_PRIORITY_11 (11)
#define ICU_PRIORITY_12 (12)
#define ICU_PRIORITY_13 (13)
#define ICU_PRIORITY_14 (14)
#define ICU_PRIORITY_15 (15)

#define ICU_IEC_MASK_SET (1)

#define ICU_PIC_EDGE_CLEAR (1)

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables and functions (to be accessed by other files)
*******************************************************************************/
void R_ICU_Disable(uint32_t vec_num);
void R_ICU_Enable(uint32_t vec_num);
void R_ICU_ExtPinInit(uint16_t pin_num, uint8_t detect, uint32_t dnf_set);
void R_ICU_Regist(uint32_t vec_num, uint32_t type, uint32_t priority, uint32_t isr_addr);
void R_ICU_Disable(uint32_t vec_num);
void R_ICU_Enable(uint32_t vec_num);

#endif

/* End of File */
