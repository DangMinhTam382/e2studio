/* generated configuration header file - do not edit */
#ifndef BOARD_CFG_H_
#define BOARD_CFG_H_
#define BSP_CFG_RAM_EXECUTION (1)
void bsp_init(void *p_args);
#endif /* BOARD_CFG_H_ */
