/************************************************************************/
/*    File Version: V1.00                                               */
/*    Date Generated(DD/MM/YYYY): 09/08/2013                            */
/************************************************************************/

#ifndef INTERRUPT_HANDLERS_H
#define INTERRUPT_HANDLERS_H
// Exception(Supervisor Instruction)
void INT_Excep_SuperVisorInst(void) __attribute__ ((interrupt));

// Exception(Undefined Instruction)
void INT_Excep_UndefinedInst(void) __attribute__ ((interrupt));


// NMI
void INT_NonMaskableInterrupt(void) __attribute__ ((interrupt));

// Dummy
void Dummy (void) __attribute__ ((interrupt));

// BRK
void INT_Excep_BRK(void) __attribute__ ((interrupt));
//;0x0000  Reserved

// BSC BUSERR
void INT_Excep_BSC_BUSERR(void) __attribute__ ((interrupt));
//;0x0044  Reserved
    
// ICU SWINT
void INT_Excep_ICU_SWINT(void) __attribute__ ((interrupt));

// CMT0 CMI0
void INT_Excep_CMT0_CMI0(void) __attribute__ ((interrupt));

// CMT1 CMI1
void INT_Excep_CMT1_CMI1(void) __attribute__ ((interrupt));

// CAC FERRF
void INT_Excep_CAC_FERRF(void) __attribute__ ((interrupt));

// CAC MENDF
void INT_Excep_CAC_MENDF(void) __attribute__ ((interrupt));

// CAC OVFF
void INT_Excep_CAC_OVFF(void) __attribute__ ((interrupt));

// RSPI0 SPEI0
void INT_Excep_RSPI0_SPEI0(void) __attribute__ ((interrupt));

// RSPI0 SPRI0
void INT_Excep_RSPI0_SPRI0(void) __attribute__ ((interrupt));

// RSPI0 SPTI0
void INT_Excep_RSPI0_SPTI0(void) __attribute__ ((interrupt));

// RSPI0 SPII0
void INT_Excep_RSPI0_SPII0(void) __attribute__ ((interrupt));

// DOC DOPCF
void INT_Excep_DOC_DOPCF(void) __attribute__ ((interrupt));

// RTC CUP
void INT_Excep_RTC_CUP(void) __attribute__ ((interrupt));

// ICU IRQ0
void INT_Excep_ICU_IRQ0(void) __attribute__ ((interrupt));

// ICU IRQ1
void INT_Excep_ICU_IRQ1(void) __attribute__ ((interrupt));

// ICU IRQ2
void INT_Excep_ICU_IRQ2(void) __attribute__ ((interrupt));

// ICU IRQ3
void INT_Excep_ICU_IRQ3(void) __attribute__ ((interrupt));

// ICU IRQ4
void INT_Excep_ICU_IRQ4(void) __attribute__ ((interrupt));

// ICU IRQ5
void INT_Excep_ICU_IRQ5(void) __attribute__ ((interrupt));

// ICU IRQ6
void INT_Excep_ICU_IRQ6(void) __attribute__ ((interrupt));

// ICU IRQ7
void INT_Excep_ICU_IRQ7(void) __attribute__ ((interrupt));

// LVD LVD1
void INT_Excep_LVD_LVD1(void) __attribute__ ((interrupt));

// LVD LVD2
void INT_Excep_LVD_LVD2(void) __attribute__ ((interrupt));

// RTC ALM
void INT_Excep_RTC_ALM(void) __attribute__ ((interrupt));

// RTC PRD
void INT_Excep_RTC_PRD(void) __attribute__ ((interrupt));

// S12AD S12ADI0
void INT_Excep_S12AD_S12ADI0(void) __attribute__ ((interrupt));

// S12AD GBADI
void INT_Excep_S12AD_GBADI(void) __attribute__ ((interrupt));

// MTU0 TGIA0
void INT_Excep_MTU0_TGIA0(void) __attribute__ ((interrupt));

// MTU0 TGIB0
void INT_Excep_MTU0_TGIB0(void) __attribute__ ((interrupt));

// MTU0 TGIC0
void INT_Excep_MTU0_TGIC0(void) __attribute__ ((interrupt));

// MTU0 TGID0
void INT_Excep_MTU0_TGID0(void) __attribute__ ((interrupt));

// MTU0 TCIV0
void INT_Excep_MTU0_TCIV0(void) __attribute__ ((interrupt));

// MTU0 TGIE0
void INT_Excep_MTU0_TGIE0(void) __attribute__ ((interrupt));

// MTU0 TGIF0
void INT_Excep_MTU0_TGIF0(void) __attribute__ ((interrupt));

// MTU1 TGIA1
void INT_Excep_MTU1_TGIA1(void) __attribute__ ((interrupt));

// MTU1 TGIB1
void INT_Excep_MTU1_TGIB1(void) __attribute__ ((interrupt));

// MTU1 TCIV1
void INT_Excep_MTU1_TCIV1(void) __attribute__ ((interrupt));

// MTU1 TCIU1
void INT_Excep_MTU1_TCIU1(void) __attribute__ ((interrupt));

// MTU2 TGIA2
void INT_Excep_MTU2_TGIA2(void) __attribute__ ((interrupt));

// MTU2 TGIB2
void INT_Excep_MTU2_TGIB2(void) __attribute__ ((interrupt));

// MTU2 TCIV2
void INT_Excep_MTU2_TCIV2(void) __attribute__ ((interrupt));

// MTU2 TCIU2
void INT_Excep_MTU2_TCIU2(void) __attribute__ ((interrupt));

// MTU5 TGIU5
void INT_Excep_MTU5_TGIU5(void) __attribute__ ((interrupt));

// MTU5 TGIV5
void INT_Excep_MTU5_TGIV5(void) __attribute__ ((interrupt));

// MTU5 TGIW5
void INT_Excep_MTU5_TGIW5(void) __attribute__ ((interrupt));

// SCI1 ERI1
void INT_Excep_SCI1_ERI1(void) __attribute__ ((interrupt));

// SCI1 RXI1
void INT_Excep_SCI1_RXI1(void) __attribute__ ((interrupt));

// SCI1 TXI1
void INT_Excep_SCI1_TXI1(void) __attribute__ ((interrupt));

// SCI1 TEI1
void INT_Excep_SCI1_TEI1(void) __attribute__ ((interrupt));

// SCI5 ERI5
void INT_Excep_SCI5_ERI5(void) __attribute__ ((interrupt));

// SCI5 RXI5
void INT_Excep_SCI5_RXI5(void) __attribute__ ((interrupt));

// SCI5 TXI5
void INT_Excep_SCI5_TXI5(void) __attribute__ ((interrupt));

// SCI5 TEI5
void INT_Excep_SCI5_TEI5(void) __attribute__ ((interrupt));

// SCI12 ERI12
void INT_Excep_SCI12_ERI12(void) __attribute__ ((interrupt));

// SCI12 RXI12
void INT_Excep_SCI12_RXI12(void) __attribute__ ((interrupt));

// SCI12 TXI12
void INT_Excep_SCI12_TXI12(void) __attribute__ ((interrupt));

// SCI12 TEI12
void INT_Excep_SCI12_TEI12(void) __attribute__ ((interrupt));

// SCI12 SCIX0
void INT_Excep_SCI12_SCIX0(void) __attribute__ ((interrupt));

// SCI12 SCIX1
void INT_Excep_SCI12_SCIX1(void) __attribute__ ((interrupt));

// SCI12 SCIX2
void INT_Excep_SCI12_SCIX2(void) __attribute__ ((interrupt));

// SCI12 SCIX3
void INT_Excep_SCI12_SCIX3(void) __attribute__ ((interrupt));

// RIIC0 EEI0
void INT_Excep_RIIC0_EEI0(void) __attribute__ ((interrupt));

// RIIC0 RXI0
void INT_Excep_RIIC0_RXI0(void) __attribute__ ((interrupt));

// RIIC0 TXI0
void INT_Excep_RIIC0_TXI0(void) __attribute__ ((interrupt));

// RIIC0 TEI0
void INT_Excep_RIIC0_TEI0(void) __attribute__ ((interrupt));

//;<<VECTOR DATA START (POWER ON RESET)>>
//;Power On Reset PC
extern void PowerON_Reset(void) __attribute__ ((interrupt));                                                                                                                
//;<<VECTOR DATA END (POWER ON RESET)>>
#endif
