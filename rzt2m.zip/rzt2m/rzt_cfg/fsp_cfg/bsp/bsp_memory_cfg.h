/* generated configuration header file - do not edit */
#ifndef BSP_MEMORY_CFG_H_
#define BSP_MEMORY_CFG_H_
#define BSP_MPU_SUPPORT
#endif /* BSP_MEMORY_CFG_H_ */
