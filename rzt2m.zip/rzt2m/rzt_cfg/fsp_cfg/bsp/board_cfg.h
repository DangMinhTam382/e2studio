/* generated configuration header file - do not edit */
#ifndef BOARD_CFG_H_
#define BOARD_CFG_H_
#include "../../../rzt/board/rzt2m_rsk/board.h"
#define BSP_CFG_RAM_EXECUTION (1)
#endif /* BOARD_CFG_H_ */
