/************************************************************************/
/*    File Version: V1.00                                               */
/*    Date Generated: 10/09/2013                                        */
/************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif
extern void HardwareSetup(void);
#ifdef __cplusplus
}
#endif
void HardwareSetup(void)
{

}                                                                   